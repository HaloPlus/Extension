# Official Halo+ Extension
#### For contributing please create a new branch with your name.
##### Please refer to [conventional commit messages](https://www.conventionalcommits.org/en/v1.0.0/#summary) when committing your changes.
##### Once you're ready to merge, please create a pull request with your fork for the lead developer to review.

You can download the extension [here](https://halopl.us/extension).
URL broken? Download the extension [here](https://chromewebstore.google.com/detail/halo+/eplokpcilgnmcpbhklkepdfdcmdnppdk)